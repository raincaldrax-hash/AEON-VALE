from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="aria-rpg-engine",
    version="0.1.0",
    author="Devon",
    description="AI-first RPG game engine framework",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/DEVON1234-von/RPG-text-Sandbox-Repo",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Games/Entertainment :: Role-Playing",
    ],
    python_requires=">=3.10",
    install_requires=[
        "pydantic>=2.0",
        "sqlalchemy>=2.0",
        "python-dotenv>=1.0",
    ],
    extras_require={
        "ai": ["openai>=1.0", "anthropic>=0.7"],
        "dev": ["pytest>=7.0", "black>=23.0", "mypy>=1.0"],
    },
)

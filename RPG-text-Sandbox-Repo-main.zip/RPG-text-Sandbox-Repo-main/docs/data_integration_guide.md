# Data Integration Guide

## External Data Sources

You can integrate with several open-source RPG data repositories to avoid rebuilding everything from scratch.

### 1. **D&D 5e Open Source Data**

#### Best Projects

**[Open5e](https://github.com/open5e/open5e)**
- Complete D&D 5e SRD content (spells, monsters, items, races, classes)
- REST API available at `https://api.open5e.com`
- JSON data files
- License: Creative Commons Attribution 4.0

**[5e Database](https://github.com/5e-bits/5e-database)**
- Structured D&D 5e data
- Powers the popular D&D 5e API at `http://dnd5eapi.co`
- Complete JSON database
- Well-documented

**[dnd-data](https://github.com/nick-aschenbach/dnd-data)**
- Comprehensive Python library
- Races, classes, spells, items, monsters
- Easy to integrate

#### How to Use

```python
import json
import requests

# Fetch from Open5e API
response = requests.get('https://api.open5e.com/monsters/')
monsters = response.json()

# Or download JSON files
with open('data/monsters.json') as f:
    monster_data = json.load(f)
```

### 2. **Evennia/Ainneve**

**[Ainneve Example Game](https://github.com/evennia/ainneve)**
- Full Evennia MUD example with races, monsters, items
- Well-structured Python code
- Browse: `typeclasses/` and `world/` directories

You can copy and adapt their implementations:
- `typeclasses/characters.py` - Races and character classes
- `typeclasses/npcs.py` - Monster definitions
- `typeclasses/items.py` - Item systems

### 3. **Integration Patterns**

#### Pattern 1: JSON Data Files

Store data as JSON in `data/` directory:

```
data/
├── races.json
├── monsters.json
├── items.json
├── spells.json
└── skills.json
```

Load at startup:

```python
def load_game_data():
    with open('data/races.json') as f:
        races = json.load(f)
    # ... apply to systems
```

#### Pattern 2: REST API Integration

```python
class DataFetcher:
    def fetch_monsters(self):
        response = requests.get('https://api.open5e.com/monsters/')
        return response.json()['results']
    
    def fetch_spells(self):
        response = requests.get('https://api.open5e.com/spells/')
        return response.json()['results']
```

#### Pattern 3: Hybrid Approach

Use external data but customize locally:

```python
# Load base data from Open5e
base_monsters = fetch_from_api('monsters')

# Apply custom modifications
custom_monsters = load_local_data('data/custom_monsters.json')

# Merge
all_monsters = {**base_monsters, **custom_monsters}
```

### 4. **What to Get From Each Source**

| Data | Best Source | Format |
|------|-------------|--------|
| **Races** | 5e Database or Ainneve | JSON |
| **Monsters** | Open5e (1000+) | API/JSON |
| **Spells** | Open5e (300+) | API/JSON |
| **Items/Equipment** | 5e Database | JSON |
| **Classes** | Open5e | API/JSON |
| **Magic Schools** | Open5e (Evocation, Transmutation, etc) | API/JSON |
| **NPC Templates** | Ainneve | Python |

### 5. **Recommended Setup**

```python
# config/data_sources.py
DATAS OURCES = {
    "races": {
        "source": "local",
        "file": "data/races.json",
    },
    "monsters": {
        "source": "api",
        "url": "https://api.open5e.com/monsters",
        "cache_file": "data/monsters_cache.json",
    },
    "spells": {
        "source": "api",
        "url": "https://api.open5e.com/spells",
        "cache_file": "data/spells_cache.json",
    },
    "items": {
        "source": "local",
        "file": "data/items.json",
    },
}

# Then use in systems
from aria.systems.data_loader import DataLoader

loader = DataLoader()
monsters = loader.load_data('monsters')
```

## Quick Start

1. **Download base data**:
   ```bash
   # Clone Open5e
   git clone https://github.com/open5e/open5e.git
   # Extract JSON files to data/
   ```

2. **Create data loader**:
   ```python
   loader = DataLoader()
   races = loader.load_races('data/races.json')
   ```

3. **Integrate with Aria**:
   ```python
   from aria.systems.races import RaceSystem
   from aria.systems.monsters import MonsterSystem
   from aria.systems.items import ItemSystem
   
   race_sys = RaceSystem(custom_races=races)
   monster_sys = MonsterSystem(custom_monsters=monsters)
   item_sys = ItemSystem(custom_items=items)
   ```

## Licensing

- **Open5e**: Creative Commons Attribution 4.0
- **5e Database**: Creative Commons Attribution 4.0
- **Ainneve**: BSD License (same as Evennia)
- **MIT License (Your Aria Engine)**: Compatible with all above for redistribution

Just include attribution in your project.

## Next Steps

1. Choose your primary source (recommended: **Open5e** for completeness)
2. Download or set up API integration
3. Create data loader module
4. Map external data to your internal systems
5. Add custom content on top

# Aria RPG Engine Architecture

## Overview

Aria is a modular, AI-first game engine designed for creating personalized fantasy RPG worlds. The architecture supports both offline and online play with seamless state reconciliation.

## Core Components

### 1. Core Engine

- **World**: Central manager for all game entities and state
- **Entity**: Base class for all game objects (NPCs, items, locations)
- **GameLoop**: Main loop managing tick rate and simulation
- **Character**: Extended entity with stats, progression, and inventory

### 2. AI Systems

- **NPCAISystem**: Generates dialogue and manages NPC behavior
  - Online: LLM-powered (ChatGPT, Claude, etc.)
  - Offline: Rule-based responses

- **QuestAISystem**: Procedurally generates and tracks quests
  - Online: Dynamic, contextual quest generation
  - Offline: Template-based quest generation

- **WorldSimulation**: Simulates world state changes
  - Economy simulation
  - NPC interactions
  - World events

- **RewardSystem**: Generates loot and rewards
  - Item generation
  - Experience rewards
  - Rare drops

### 3. Game Systems

- **Combat**: Turn-based combat with damage calculation
- **Crafting**: Item creation from components
- **Skills & Magic**: Character progression systems
- **Dialogue**: NPC interaction system
- **Quests**: Quest progression tracking

### 4. Persistence

- **SaveManager**: Local save/load operations
- **Serializer**: Object serialization/deserialization
- **Migrations**: Data format version handling

### 5. Network

- **OfflineEngine**: Lightweight simulation for offline play
- **OnlineManager**: Cloud sync and full simulation
- **StateReconciler**: Merge offline/online state changes

## Data Flow

### Offline Mode

```
Player Input -> Local GameLoop -> Lightweight AI Systems -> Local Save
                     ↓
              World Simulation
               (Limited)
```

### Online Mode

```
Player Input -> GameLoop -> Full AI Systems -> Cloud State -> Sync
                  ↓
            World Simulation
            (Full Systems)
```

### State Reconciliation

When going online after offline play:

1. Load offline world state
2. Simulate what would have happened online (time-delta)
3. Apply cloud updates
4. Merge conflicts (player changes win)
5. Update local state

## Extension Points

Developers can extend Aria by:

1. **Custom AI Systems**: Inherit from `AISystem`
2. **Custom Game Mechanics**: Add to `game/` module
3. **Custom Content**: Data-driven via JSON/YAML
4. **Custom Serializers**: Extend `Serializer` class

## Configuration

All systems are configured via `config/` directory:

- `settings.py`: Engine settings
- `game_config.json`: Game-specific settings
- `ai_prompts.json`: LLM system prompts
- `content/`: Game content (items, spells, NPCs)

## Dependencies

- **SQLAlchemy**: ORM for persistent storage
- **Pydantic**: Data validation
- **OpenAI/Anthropic**: LLM integration
- **asyncio**: Async simulation

# Getting Started with Aria RPG Engine

## Installation

### Prerequisites

- Python 3.10 or higher
- pip

### Setup

1. Clone the repository:
```bash
git clone https://github.com/DEVON1234-von/RPG-text-Sandbox-Repo.git
cd RPG-text-Sandbox-Repo
```

2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

## Running the Example Game

```bash
python -m examples.fantasy_realm.main
```

This will start a simple fantasy RPG where you can:
- Explore different locations
- Talk to NPCs
- Accept and complete quests
- Engage in combat
- Manage inventory

## Basic Game Loop

Here's a minimal Aria game:

```python
from src.aria.core.world import World
from src.aria.core.game_loop import GameLoop
from src.aria.game.character import Character
import asyncio

async def main():
    # Create world
    world = World(
        id="fantasy_world",
        name="The Forgotten Realm",
        description="A vast fantasy world"
    )
    
    # Create player character
    player = Character(
        name="Hero",
        description="You are the hero of this story"
    )
    
    # Add to world
    world.add_entity(player)
    
    # Create game loop
    game_loop = GameLoop(world, tick_rate=60)
    
    # Register callbacks
    async def on_tick(tick):
        if tick % 60 == 0:  # Every second
            print(f"Tick {tick}, Time: {world.time:.1f}s")
    
    game_loop.register_tick_callback(on_tick)
    
    # Run for 10 seconds
    await game_loop.run(max_ticks=600)

if __name__ == "__main__":
    asyncio.run(main())
```

## Next Steps

- Read [Creating Games](creating_games.md) to build your own game
- Check [API Reference](api_reference.md) for detailed API documentation
- Explore [AI Systems](ai_systems.md) for LLM integration

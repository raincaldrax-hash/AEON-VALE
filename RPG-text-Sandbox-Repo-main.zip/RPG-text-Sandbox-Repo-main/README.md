# Aria RPG Engine

A Python-based, AI-first game engine framework for building personalized, procedurally-generated fantasy RPG worlds.

## Features

- **AI-Driven Worlds**: Dynamic NPCs, procedural quests, intelligent world simulation
- **Hybrid Online/Offline**: Works seamlessly offline with automatic world simulation; syncs with cloud when online
- **Single-Player Persistence**: Each player gets their own personalized, evolving world
- **Extensible Architecture**: Plug-and-play AI systems, customizable game mechanics
- **Rich Game Systems**: Combat, crafting, skills, magic, dialogue, lore, and more
- **Developer-Friendly**: Clean API for building games on top of the engine

## Quick Start

### Installation

```bash
git clone https://github.com/DEVON1234-von/RPG-text-Sandbox-Repo.git
cd RPG-text-Sandbox-Repo
pip install -r requirements.txt
```

### Running the Example Game

```bash
python -m examples.fantasy_realm.main
```

### Building Your Own Game

See [Creating Games](docs/creating_games.md) for a complete guide.

## Architecture

```
Aria Engine
├── Core (world, entities, game loop)
├── AI Systems (NPCs, quests, economy, world simulation)
├── Game Mechanics (combat, crafting, dialogue, skills)
├── Persistence (save/load, offline/online sync)
└── Network (hybrid online/offline coordination)
```

For detailed architecture, see [Architecture Guide](docs/architecture.md).

## Documentation

- [Getting Started](docs/getting_started.md)
- [API Reference](docs/api_reference.md)
- [AI Systems Guide](docs/ai_systems.md)
- [Creating Games](docs/creating_games.md)
- [Architecture](docs/architecture.md)

## License

MIT License - See LICENSE file for details

## Contributing

Contributions welcome! Please see CONTRIBUTING.md for guidelines.

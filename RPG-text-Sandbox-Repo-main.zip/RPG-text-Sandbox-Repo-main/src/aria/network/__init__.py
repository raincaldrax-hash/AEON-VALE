"""Online/offline network coordination"""

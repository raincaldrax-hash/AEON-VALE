"""Lightweight offline game engine"""

from typing import Optional
from src.aria.core.world import World
from src.aria.core.game_loop import GameLoop


class OfflineEngine:
    """Manages offline game state and limited simulations"""
    
    def __init__(self, world: World):
        """
        Initialize offline engine
        
        Args:
            world: World instance
        """
        self.world = world
        self.game_loop = GameLoop(world, tick_rate=10.0)  # Lower tick rate offline
        self.is_running = False
    
    async def run_offline_simulation(self, duration: float) -> None:
        """
        Run world simulation while offline
        
        Args:
            duration: Simulation duration in seconds
        """
        import asyncio
        
        ticks = int(duration * self.game_loop.tick_rate)
        self.is_running = True
        
        try:
            await self.game_loop.run(max_ticks=ticks)
        finally:
            self.is_running = False
    
    def stop_simulation(self) -> None:
        """Stop offline simulation"""
        self.game_loop.stop()
        self.is_running = False

"""Items and equipment system"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum


class ItemType(Enum):
    """Item classification"""
    WEAPON = "weapon"
    ARMOR = "armor"
    ACCESSORY = "accessory"
    CONSUMABLE = "consumable"
    QUEST = "quest"
    TREASURE = "treasure"
    CRAFTING = "crafting"
    SPELL_SCROLL = "spell_scroll"
    POTION = "potion"
    TOOL = "tool"


class EquipmentSlot(Enum):
    """Equipment slots on character"""
    MAIN_HAND = "main_hand"
    OFF_HAND = "off_hand"
    BOTH_HANDS = "both_hands"
    HEAD = "head"
    NECK = "neck"
    CHEST = "chest"
    HANDS = "hands"
    FINGERS = "fingers"  # Can have multiple
    WAIST = "waist"
    LEGS = "legs"
    FEET = "feet"
    BACK = "back"


class Rarity(Enum):
    """Item rarity"""
    COMMON = "common"
    UNCOMMON = "uncommon"
    RARE = "rare"
    VERY_RARE = "very_rare"
    LEGENDARY = "legendary"
    ARTIFACT = "artifact"


@dataclass
class Item:
    """Item definition"""
    id: str
    name: str
    description: str
    item_type: ItemType
    
    # Properties
    weight: float = 0.0  # pounds
    value: int = 0  # gold pieces
    rarity: Rarity = Rarity.COMMON
    
    # Stats
    armor_class_bonus: int = 0
    damage_bonus: int = 0
    health_bonus: int = 0
    stat_bonuses: Dict[str, int] = field(default_factory=dict)
    
    # Equipment
    is_equippable: bool = False
    equipment_slot: Optional[EquipmentSlot] = None
    requires_attunement: bool = False
    max_stacks: int = 1  # 1 = not stackable
    
    # Weapon specific
    damage_dice: str = ""  # e.g., "1d8"
    damage_type: str = ""  # slashing, piercing, etc.
    
    # Consumable/Potion
    effect: str = ""  # What it does
    duration: int = 0  # turns or minutes
    
    # Magical
    is_magical: bool = False
    magical_properties: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "type": self.item_type.value,
            "value": self.value,
            "rarity": self.rarity.value,
            "is_magical": self.is_magical,
        }


class ItemSystem:
    """Manages items and equipment"""
    
    # Default items inspired by D&D
    DEFAULT_ITEMS = {
        # Weapons
        "shortsword": Item(
            id="shortsword",
            name="Shortsword",
            description="A short blade suitable for melee combat",
            item_type=ItemType.WEAPON,
            is_equippable=True,
            equipment_slot=EquipmentSlot.MAIN_HAND,
            weight=2.0,
            value=10,
            damage_dice="1d6",
            damage_type="slashing",
            damage_bonus=1,
        ),
        "longsword": Item(
            id="longsword",
            name="Longsword",
            description="A versatile blade for both one and two-handed use",
            item_type=ItemType.WEAPON,
            is_equippable=True,
            equipment_slot=EquipmentSlot.MAIN_HAND,
            weight=3.0,
            value=15,
            damage_dice="1d8",
            damage_type="slashing",
            damage_bonus=1,
        ),
        "bow": Item(
            id="bow",
            name="Longbow",
            description="A ranged weapon for attacking from distance",
            item_type=ItemType.WEAPON,
            is_equippable=True,
            equipment_slot=EquipmentSlot.MAIN_HAND,
            weight=2.0,
            value=50,
            damage_dice="1d8",
            damage_type="piercing",
        ),
        "warhammer": Item(
            id="warhammer",
            name="Warhammer",
            description="A heavy two-handed weapon for powerful strikes",
            item_type=ItemType.WEAPON,
            is_equippable=True,
            equipment_slot=EquipmentSlot.BOTH_HANDS,
            weight=6.0,
            value=15,
            damage_dice="2d6",
            damage_type="bludgeoning",
            damage_bonus=2,
        ),
        
        # Armor
        "leather_armor": Item(
            id="leather_armor",
            name="Leather Armor",
            description="Light protective gear made of hardened leather",
            item_type=ItemType.ARMOR,
            is_equippable=True,
            equipment_slot=EquipmentSlot.CHEST,
            weight=10.0,
            value=5,
            armor_class_bonus=1,
        ),
        "chainmail": Item(
            id="chainmail",
            name="Chainmail",
            description="Medium armor of interlocking metal rings",
            item_type=ItemType.ARMOR,
            is_equippable=True,
            equipment_slot=EquipmentSlot.CHEST,
            weight=55.0,
            value=75,
            armor_class_bonus=2,
        ),
        "plate_armor": Item(
            id="plate_armor",
            name="Plate Armor",
            description="Heavy protective armor made of metal plates",
            item_type=ItemType.ARMOR,
            is_equippable=True,
            equipment_slot=EquipmentSlot.CHEST,
            weight=65.0,
            value=1500,
            armor_class_bonus=3,
        ),
        
        # Potions
        "potion_healing": Item(
            id="potion_healing",
            name="Potion of Healing",
            description="Restores 2d4+2 health when consumed",
            item_type=ItemType.POTION,
            weight=0.5,
            value=50,
            rarity=Rarity.COMMON,
            effect="heal_2d4_2",
            max_stacks=10,
        ),
        "potion_strength": Item(
            id="potion_strength",
            name="Potion of Strength",
            description="Grants +2 to Strength for 1 hour",
            item_type=ItemType.POTION,
            weight=0.5,
            value=100,
            rarity=Rarity.UNCOMMON,
            effect="strength_+2",
            duration=60,
            max_stacks=5,
        ),
        
        # Magical Items
        "ring_protection": Item(
            id="ring_protection",
            name="Ring of Protection",
            description="Grants +1 to AC and saving throws",
            item_type=ItemType.ACCESSORY,
            is_equippable=True,
            equipment_slot=EquipmentSlot.FINGERS,
            weight=0.1,
            value=500,
            rarity=Rarity.RARE,
            is_magical=True,
            armor_class_bonus=1,
            requires_attunement=True,
        ),
        "amulet_health": Item(
            id="amulet_health",
            name="Amulet of Health",
            description="Sets your Constitution to 19 while worn",
            item_type=ItemType.ACCESSORY,
            is_equippable=True,
            equipment_slot=EquipmentSlot.NECK,
            weight=0.1,
            value=1000,
            rarity=Rarity.RARE,
            is_magical=True,
            stat_bonuses={"constitution": 9},
            requires_attunement=True,
        ),
        
        # Resources
        "wood": Item(
            id="wood",
            name="Wood",
            description="A bundle of wooden planks",
            item_type=ItemType.CRAFTING,
            weight=1.0,
            value=1,
            max_stacks=100,
        ),
        "stone": Item(
            id="stone",
            name="Stone",
            description="Rough cut stone for building",
            item_type=ItemType.CRAFTING,
            weight=2.0,
            value=1,
            max_stacks=100,
        ),
        "gold_ore": Item(
            id="gold_ore",
            name="Gold Ore",
            description="Raw ore containing gold",
            item_type=ItemType.CRAFTING,
            weight=1.0,
            value=10,
            max_stacks=50,
        ),
    }
    
    def __init__(self, custom_items: Optional[Dict[str, Item]] = None):
        self.items = dict(self.DEFAULT_ITEMS)
        if custom_items:
            self.items.update(custom_items)
    
    def get_item(self, item_id: str) -> Optional[Item]:
        """Get item by ID"""
        return self.items.get(item_id)
    
    def add_item(self, item: Item) -> None:
        """Add custom item"""
        self.items[item.id] = item
    
    def list_items(self) -> List[str]:
        """List all items"""
        return list(self.items.keys())
    
    def get_items_by_type(self, item_type: ItemType) -> List[Item]:
        """Get items of a type"""
        return [item for item in self.items.values() if item.item_type == item_type]
    
    def get_weapons(self) -> List[Item]:
        """Get all weapons"""
        return self.get_items_by_type(ItemType.WEAPON)
    
    def get_armor(self) -> List[Item]:
        """Get all armor"""
        return self.get_items_by_type(ItemType.ARMOR)
    
    def get_magical_items(self) -> List[Item]:
        """Get all magical items"""
        return [item for item in self.items.values() if item.is_magical]
    
    def get_items_by_rarity(self, rarity: Rarity) -> List[Item]:
        """Get items of a rarity"""
        return [item for item in self.items.values() if item.rarity == rarity]

"""Races system with predefined races and customizable traits"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from enum import Enum


class RaceType(Enum):
    """Available races"""
    HUMAN = "human"
    ELF = "elf"
    DWARF = "dwarf"
    HALFLING = "halfling"
    ORC = "orc"
    TIEFLING = "tiefling"
    DRAGONBORN = "dragonborn"
    GNOME = "gnome"
    HALF_ELF = "half_elf"
    HALF_ORC = "half_orc"
    DEMON = "demon"
    BEASTFOLK = "beastfolk"
    GOBLIN = "goblin"


@dataclass
class RaceAbility:
    """Racial ability bonuses"""
    name: str
    description: str
    bonus_type: str  # "stat", "skill", "spell", "trait"
    bonus_target: str  # stat name, skill name, etc
    bonus_amount: int = 1
    bonus_value: int = 0  # Additional value like +2 to a stat


@dataclass
class Race:
    """Race definition with traits and bonuses"""
    id: str
    name: str
    description: str
    size: str = "Medium"  # Small, Medium, Large
    speed: int = 30  # feet per turn
    
    # Stat bonuses
    stat_bonuses: Dict[str, int] = field(default_factory=dict)  # stat -> bonus
    # Example: {"strength": 2, "constitution": 1}
    
    # Skills and traits
    natural_abilities: List[str] = field(default_factory=list)
    skill_proficiencies: List[str] = field(default_factory=list)
    spell_affinities: Dict[str, int] = field(default_factory=dict)  # spell -> bonus
    
    # Combat traits
    natural_weapons: List[str] = field(default_factory=list)
    resistances: List[str] = field(default_factory=list)
    vulnerabilities: List[str] = field(default_factory=list)
    immunities: List[str] = field(default_factory=list)
    
    # Life traits
    lifespan: int = 80  # average years
    maturation_age: int = 18
    height_range: str = "5-6 ft"  # example
    
    def get_stat_bonus(self, stat: str) -> int:
        """Get bonus for a stat"""
        return self.stat_bonuses.get(stat, 0)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "size": self.size,
            "speed": self.speed,
            "lifespan": self.lifespan,
            "stat_bonuses": self.stat_bonuses,
            "natural_abilities": self.natural_abilities,
            "skill_proficiencies": self.skill_proficiencies,
            "resistances": self.resistances,
            "immunities": self.immunities,
        }


class RaceSystem:
    """Manages all playable races"""
    
    # Default races inspired by D&D 5e with accurate lifespans
    DEFAULT_RACES = {
        "human": Race(
            id="human",
            name="Human",
            description="Versatile and ambitious, humans are found in every corner of the world. Short-lived but prolific.",
            size="Medium",
            speed=30,
            stat_bonuses={"strength": 1, "dexterity": 1, "constitution": 1, 
                         "intelligence": 1, "wisdom": 1, "charisma": 1},
            natural_abilities=["adaptability", "extra_feat", "bonus_skill"],
            skill_proficiencies=[],
            lifespan=100,
            maturation_age=18,
            height_range="5-6 ft",
        ),
        "elf": Race(
            id="elf",
            name="Elf",
            description="Graceful and long-lived, elves are known for their magical affinity and immortal beauty. They value art and nature.",
            size="Medium",
            speed=30,
            stat_bonuses={"dexterity": 2},
            natural_abilities=["darkvision_60ft", "keen_senses", "fey_ancestry", "trance_meditation", "fey_magic"],
            skill_proficiencies=["perception"],
            spell_affinities={"magic": 2, "nature": 1},
            lifespan=750,  # Elves live ~750 years
            maturation_age=100,  # Takes 100 years to reach adulthood
            height_range="4.5-6 ft",
        ),
        "dwarf": Race(
            id="dwarf",
            name="Dwarf",
            description="Stout and strong, dwarves are master builders and warriors. Excellent stonecrafters with a love of ale and battle.",
            size="Medium",
            speed=25,
            stat_bonuses={"constitution": 2},
            natural_abilities=["darkvision_60ft", "stonecunning", "dwarven_resilience", "battle_hardened"],
            skill_proficiencies=[],
            resistances=["poison"],
            lifespan=350,  # Dwarves live ~350 years
            maturation_age=50,
            height_range="3.5-4.5 ft",
        ),
        "orc": Race(
            id="orc",
            name="Orc",
            description="Fierce and powerful, orcs are driven by strength and honor. Often misunderstood but deeply loyal to their tribes.",
            size="Medium",
            speed=30,
            stat_bonuses={"strength": 2, "constitution": 1},
            natural_abilities=["darkvision_60ft", "aggressive_charge", "powerful_build", "relentless_endurance", "primal_instinct"],
            skill_proficiencies=["intimidation"],
            natural_weapons=["tusks", "claws"],
            lifespan=80,
            maturation_age=14,
            height_range="6-7 ft",
        ),
        "halfling": Race(
            id="halfling",
            name="Halfling",
            description="Small and nimble, halflings are known for luck and cunning. Often adventurous despite their love of home.",
            size="Small",
            speed=25,
            stat_bonuses={"dexterity": 2},
            natural_abilities=["lucky", "halfling_nimbleness", "fearless_nature"],
            skill_proficiencies=[],
            lifespan=150,  # Halflings live ~150 years
            maturation_age=20,
            height_range="2.5-3.5 ft",
        ),
        "tiefling": Race(
            id="tiefling",
            name="Tiefling",
            description="Infernal heritage marks these creatures with otherworldly features. Often cursed or blessed with magical power.",
            size="Medium",
            speed=30,
            stat_bonuses={"charisma": 2, "intelligence": 1},
            natural_abilities=["darkvision_60ft", "hellish_resistance", "infernal_legacy", "arcane_affinity"],
            spell_affinities={"fire": 2, "magic": 1, "dark_magic": 1},
            resistances=["fire"],
            lifespan=110,
            maturation_age=18,
            height_range="5-6 ft",
        ),
        "dragonborn": Race(
            id="dragonborn",
            name="Dragonborn",
            description="Dragon-descended warriors with draconic power flowing through their veins. Proud and noble.",
            size="Medium",
            speed=30,
            stat_bonuses={"strength": 2, "charisma": 1},
            natural_abilities=["draconic_ancestry", "breath_weapon", "draconic_resilience", "dragon_fear"],
            skill_proficiencies=[],
            natural_weapons=["claws", "wings"],
            resistances=["varies_by_dragon_type"],
            lifespan=80,
            maturation_age=15,
            height_range="6-7 ft",
        ),
        "gnome": Race(
            id="gnome",
            name="Gnome",
            description="Small and inventive, gnomes are tinkerers and dreamers. Known for curiosity and cleverness.",
            size="Small",
            speed=25,
            stat_bonuses={"intelligence": 2},
            natural_abilities=["darkvision_60ft", "gnome_cunning", "tinkering", "natural_alchemist"],
            spell_affinities={"illusion": 1, "transmutation": 1},
            lifespan=500,  # Gnomes live ~500 years
            maturation_age=40,
            height_range="3-3.5 ft",
        ),
        "demon": Race(
            id="demon",
            name="Demon",
            description="Beings of chaos and power from infernal planes. Demons are ambitious, cunning, and often malevolent.",
            size="Medium",
            speed=30,
            stat_bonuses={"strength": 1, "charisma": 2, "constitution": 1},
            natural_abilities=[
                "darkvision_120ft", 
                "demon_resilience", 
                "hellfire_affinity",
                "infernal_magic",
                "demonic_presence",
                "flight_ability",
                "fear_aura",
            ],
            spell_affinities={"fire": 2, "dark_magic": 3, "chaos_magic": 2},
            natural_weapons=["claws", "horns", "tail"],
            resistances=["fire", "poison", "dark_magic"],
            immunities=["fire"],
            lifespan=2000,  # Demons are ancient, living thousands of years
            maturation_age=200,
            height_range="6-8 ft",
        ),
        "beastfolk": Race(
            id="beastfolk",
            name="Beastfolk",
            description="Humanoids with animal features and instincts. Includes wolves, bears, cats, and more. Tribal and primal.",
            size="Medium",
            speed=35,
            stat_bonuses={"strength": 1, "dexterity": 1, "wisdom": 1},
            natural_abilities=[
                "animal_instincts",
                "keen_senses",
                "natural_weapons_variety",
                "primal_strength",
                "tracking",
                "pack_mentality",
                "enhanced_smell",
                "natural_agility",
            ],
            skill_proficiencies=["survival", "perception"],
            natural_weapons=["claws", "fangs", "horns"],
            resistances=[],
            lifespan=120,  # Beastfolk live about as long as humans
            maturation_age=15,
            height_range="5-7 ft",
        ),
        "goblin": Race(
            id="goblin",
            name="Goblin",
            description="Small, cunning creatures driven by greed and survival. Often chaotic but capable of incredible ingenuity.",
            size="Small",
            speed=30,
            stat_bonuses={"dexterity": 2},
            natural_abilities=["darkvision_60ft", "goblin_cunning", "scavenging", "quick_reflexes", "nimble_escape"],
            skill_proficiencies=["stealth"],
            lifespan=60,
            maturation_age=10,
            height_range="3-3.5 ft",
        ),
    }
    
    def __init__(self, custom_races: Optional[Dict[str, Race]] = None):
        self.races = dict(self.DEFAULT_RACES)
        if custom_races:
            self.races.update(custom_races)
    
    def get_race(self, race_id: str) -> Optional[Race]:
        """Get race by ID"""
        return self.races.get(race_id)
    
    def add_race(self, race: Race) -> None:
        """Add custom race"""
        self.races[race.id] = race
    
    def list_races(self) -> List[str]:
        """List all available races"""
        return list(self.races.keys())
    
    def apply_race_bonuses(self, character: Any, race_id: str) -> bool:
        """Apply race bonuses to character"""
        race = self.get_race(race_id)
        if not race:
            return False
        
        # Apply stat bonuses
        for stat, bonus in race.stat_bonuses.items():
            # This assumes character has these attributes
            if stat == "strength":
                character.strength += bonus
            elif stat == "dexterity":
                character.dexterity += bonus
            elif stat == "constitution":
                character.constitution += bonus
                character.max_health += bonus * 5
            elif stat == "intelligence":
                character.intelligence += bonus
            elif stat == "wisdom":
                character.wisdom += bonus
            elif stat == "charisma":
                character.charisma += bonus
        
        # Add skills
        skills = character.get_property("skills", {})
        for skill in race.skill_proficiencies:
            skills[skill] = skills.get(skill, 0) + 1
        character.update_property("skills", skills)
        
        # Add abilities
        abilities = character.get_property("abilities", [])
        abilities.extend(race.natural_abilities)
        character.update_property("abilities", abilities)
        
        # Add resistances
        resistances = character.get_property("resistances", [])
        resistances.extend(race.resistances)
        character.update_property("resistances", resistances)
        
        # Add immunities
        immunities = character.get_property("immunities", [])
        immunities.extend(race.immunities)
        character.update_property("immunities", immunities)
        
        character.update_property("race", race_id)
        character.update_property("lifespan", race.lifespan)
        return True

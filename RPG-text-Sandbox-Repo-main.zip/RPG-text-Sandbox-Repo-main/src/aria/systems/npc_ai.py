"""NPC dialogue and behavior AI system"""

from typing import Dict, Any, Optional, List
from src.aria.systems.ai_base import AISystem
from src.aria.core.entity import Entity


class NPCAISystem(AISystem):
    """Manages NPC behavior and dialogue generation"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        super().__init__(config)
        self.npcs: Dict[str, Entity] = {}
        self.dialogue_memory: Dict[str, List[str]] = {}  # NPC dialogue history
        self.llm_client = None  # Will be initialized in initialize()
    
    async def initialize(self) -> None:
        """Initialize NPC AI system"""
        if self.is_online() and self.config.get("use_llm"):
            # Initialize LLM client (OpenAI, Anthropic, etc.)
            llm_provider = self.config.get("llm_provider", "openai")
            # TODO: Initialize based on provider
            pass
    
    async def update(self, delta_time: float) -> None:
        """Update NPC behaviors and generate dialogue"""
        for npc_id, npc in self.npcs.items():
            # Offline mode: use simple rule-based dialogue
            if not self.is_online():
                await self._update_npc_offline(npc, delta_time)
            else:
                # Online mode: use LLM for intelligent dialogue
                await self._update_npc_online(npc, delta_time)
    
    async def _update_npc_offline(self, npc: Entity, delta_time: float) -> None:
        """Update NPC in offline mode (lightweight)"""
        # Simple mood/state changes
        current_mood = npc.get_property("mood", "neutral")
        npc.update_property("mood", self._get_next_mood(current_mood))
    
    async def _update_npc_online(self, npc: Entity, delta_time: float) -> None:
        """Update NPC in online mode (LLM-powered)"""
        if not self.llm_client:
            return
        
        # Generate NPC thoughts/behaviors using LLM
        context = self._build_npc_context(npc)
        # TODO: Call LLM and update NPC state
    
    def register_npc(self, npc: Entity) -> None:
        """Register NPC for AI management"""
        self.npcs[npc.id] = npc
        self.dialogue_memory[npc.id] = []
    
    def unregister_npc(self, npc_id: str) -> None:
        """Unregister NPC"""
        self.npcs.pop(npc_id, None)
        self.dialogue_memory.pop(npc_id, None)
    
    async def generate_dialogue(self, npc_id: str, context: str) -> str:
        """Generate dialogue for NPC"""
        npc = self.npcs.get(npc_id)
        if not npc:
            return "..."
        
        if self.is_online() and self.llm_client:
            return await self._generate_dialogue_llm(npc, context)
        else:
            return await self._generate_dialogue_rule_based(npc, context)
    
    async def _generate_dialogue_llm(self, npc: Entity, context: str) -> str:
        """Generate dialogue using LLM"""
        # TODO: Implement LLM-based dialogue
        return "Hello, adventurer!"
    
    async def _generate_dialogue_rule_based(self, npc: Entity, context: str) -> str:
        """Generate dialogue using rule-based system"""
        npc_type = npc.get_property("type", "generic")
        
        # Simple rule-based responses
        responses = {
            "merchant": ["Interested in buying anything?", "I have fine wares!"],
            "guard": ["Move along.", "Stay out of trouble."],
            "sage": ["The mysteries are vast.", "Seek wisdom, young one."],
        }
        
        npc_responses = responses.get(npc_type, ["Hello.", "How can I help?"])
        import random
        return random.choice(npc_responses)
    
    def _get_next_mood(self, current_mood: str) -> str:
        """Simple mood progression"""
        moods = ["happy", "neutral", "sad", "angry"]
        try:
            idx = moods.index(current_mood)
            return moods[(idx + 1) % len(moods)]
        except ValueError:
            return "neutral"
    
    def _build_npc_context(self, npc: Entity) -> str:
        """Build context for LLM prompt"""
        return f"NPC: {npc.name}\nType: {npc.get_property('type')}\n{npc.description}"
    
    async def shutdown(self) -> None:
        """Shutdown NPC AI system"""
        self.npcs.clear()
        self.dialogue_memory.clear()

"""Monster and creature system with expanded bestiary"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import random


class MonsterType(Enum):
    """Monster classifications"""
    BEAST = "beast"
    UNDEAD = "undead"
    HUMANOID = "humanoid"
    DRAGON = "dragon"
    ELEMENTAL = "elemental"
    FIEND = "fiend"
    GIANT = "giant"
    MONSTROSITY = "monstrosity"
    PLANT = "plant"
    CONSTRUCT = "construct"


class MonsterSize(Enum):
    """Monster sizes"""
    TINY = ("Tiny", 1)
    SMALL = ("Small", 2)
    MEDIUM = ("Medium", 4)
    LARGE = ("Large", 8)
    HUGE = ("Huge", 16)
    GARGANTUAN = ("Gargantuan", 32)


@dataclass
class Monster:
    """Monster/creature definition"""
    id: str
    name: str
    description: str
    monster_type: MonsterType
    size: MonsterSize = MonsterSize.MEDIUM
    
    # Stats
    armor_class: int = 10
    health: int = 10
    speed: int = 30
    
    # Ability scores
    strength: int = 10
    dexterity: int = 10
    constitution: int = 10
    intelligence: int = 10
    wisdom: int = 10
    charisma: int = 10
    
    # Combat
    attack_bonus: int = 0
    damage_dice: str = "1d6"  # Damage roll format
    damage_type: str = "slashing"
    special_attacks: List[str] = field(default_factory=list)
    
    # Traits
    skills: Dict[str, int] = field(default_factory=dict)
    resistances: List[str] = field(default_factory=list)
    immunities: List[str] = field(default_factory=list)
    vulnerabilities: List[str] = field(default_factory=list)
    
    # Abilities
    natural_abilities: List[str] = field(default_factory=list)
    languages: List[str] = field(default_factory=list)
    
    # Challenge and rewards
    challenge_rating: float = 0.5  # 0-30
    experience_reward: int = 100
    loot_table: List[str] = field(default_factory=list)
    
    def calculate_modifier(self, ability_score: int) -> int:
        """Calculate ability modifier"""
        return (ability_score - 10) // 2
    
    def get_armor_class(self) -> int:
        """Get effective armor class"""
        dex_mod = self.calculate_modifier(self.dexterity)
        return max(self.armor_class, 10 + dex_mod)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "type": self.monster_type.value,
            "size": self.size.value[0],
            "ac": self.get_armor_class(),
            "hp": self.health,
            "speed": self.speed,
            "challenge": self.challenge_rating,
            "xp": self.experience_reward,
        }


class MonsterSystem:
    """Manages monsters and creatures"""
    
    # Expanded default monsters (50+ varieties)
    DEFAULT_MONSTERS = {
        # CR 0-1: Weak creatures
        "goblin": Monster(
            id="goblin",
            name="Goblin",
            description="A small, green-skinned humanoid prone to mischief",
            monster_type=MonsterType.HUMANOID,
            size=MonsterSize.SMALL,
            armor_class=15,
            health=7,
            strength=8,
            dexterity=14,
            constitution=10,
            intelligence=10,
            wisdom=8,
            charisma=8,
            attack_bonus=2,
            damage_dice="1d6+2",
            damage_type="slashing",
            challenge_rating=0.25,
            experience_reward=50,
            loot_table=["copper_coins", "dagger"],
        ),
        "kobold": Monster(
            id="kobold",
            name="Kobold",
            description="A small reptilian creature, cowardly but cunning",
            monster_type=MonsterType.HUMANOID,
            size=MonsterSize.SMALL,
            armor_class=12,
            health=5,
            strength=7,
            dexterity=15,
            constitution=9,
            intelligence=8,
            wisdom=7,
            charisma=8,
            attack_bonus=1,
            damage_dice="1d4",
            damage_type="piercing",
            challenge_rating=0.125,
            experience_reward=25,
            loot_table=["copper_coins"],
        ),
        "wolf": Monster(
            id="wolf",
            name="Wolf",
            description="A feral predator of the wilderness",
            monster_type=MonsterType.BEAST,
            size=MonsterSize.MEDIUM,
            armor_class=13,
            health=11,
            strength=12,
            dexterity=15,
            constitution=12,
            intelligence=3,
            wisdom=12,
            charisma=6,
            attack_bonus=2,
            damage_dice="1d6+2",
            damage_type="piercing",
            special_attacks=["pack_tactics"],
            challenge_rating=0.25,
            experience_reward=50,
            loot_table=[],
        ),
        "giant_spider": Monster(
            id="giant_spider",
            name="Giant Spider",
            description="An enormous arachnid the size of a horse",
            monster_type=MonsterType.BEAST,
            size=MonsterSize.LARGE,
            armor_class=14,
            health=26,
            strength=14,
            dexterity=16,
            constitution=13,
            intelligence=1,
            wisdom=11,
            charisma=2,
            attack_bonus=4,
            damage_dice="1d8+2",
            damage_type="piercing",
            special_attacks=["web", "poison"],
            challenge_rating=1,
            experience_reward=200,
            loot_table=["silk"],
        ),
        # CR 1-2: Standard threats
        "orc_warrior": Monster(
            id="orc_warrior",
            name="Orc Warrior",
            description="A muscular orc brandishing a greatsword",
            monster_type=MonsterType.HUMANOID,
            size=MonsterSize.LARGE,
            armor_class=13,
            health=15,
            strength=16,
            dexterity=12,
            constitution=14,
            intelligence=8,
            wisdom=11,
            charisma=10,
            attack_bonus=3,
            damage_dice="2d6+3",
            damage_type="slashing",
            special_attacks=["aggressive_charge"],
            challenge_rating=1,
            experience_reward=200,
            loot_table=["silver_coins", "greatsword", "hide_armor"],
        ),
        "bandit_captain": Monster(
            id="bandit_captain",
            name="Bandit Captain",
            description="A scarred veteran who leads a band of thieves",
            monster_type=MonsterType.HUMANOID,
            size=MonsterSize.MEDIUM,
            armor_class=15,
            health=27,
            strength=15,
            dexterity=16,
            constitution=13,
            intelligence=12,
            wisdom=11,
            charisma=14,
            attack_bonus=3,
            damage_dice="1d8+3",
            damage_type="slashing",
            special_attacks=["parry"],
            challenge_rating=1,
            experience_reward=200,
            loot_table=["gold_coins", "rapier"],
        ),
        "ghost": Monster(
            id="ghost",
            name="Ghost",
            description="A translucent spirit haunting these halls",
            monster_type=MonsterType.UNDEAD,
            size=MonsterSize.MEDIUM,
            armor_class=11,
            health=22,
            strength=7,
            dexterity=13,
            constitution=10,
            intelligence=10,
            wisdom=12,
            charisma=17,
            attack_bonus=3,
            damage_dice="1d6",
            damage_type="psychic",
            immunities=["poison", "exhaustion"],
            natural_abilities=["ethereal", "possession"],
            challenge_rating=2,
            experience_reward=450,
            loot_table=[],
        ),
        "zombie": Monster(
            id="zombie",
            name="Zombie",
            description="The reanimated corpse of a fallen creature",
            monster_type=MonsterType.UNDEAD,
            size=MonsterSize.MEDIUM,
            armor_class=8,
            health=22,
            strength=13,
            dexterity=6,
            constitution=16,
            intelligence=3,
            wisdom=6,
            charisma=5,
            attack_bonus=3,
            damage_dice="1d6+3",
            damage_type="slashing",
            immunities=["poison"],
            challenge_rating=0.25,
            experience_reward=50,
            loot_table=[],
        ),
        "fire_elemental": Monster(
            id="fire_elemental",
            name="Fire Elemental",
            description="A humanoid creature made of living flames",
            monster_type=MonsterType.ELEMENTAL,
            size=MonsterSize.LARGE,
            armor_class=15,
            health=39,
            strength=10,
            dexterity=17,
            constitution=16,
            intelligence=6,
            wisdom=10,
            charisma=7,
            attack_bonus=3,
            damage_dice="2d6+3",
            damage_type="fire",
            resistances=["bludgeoning", "piercing", "slashing"],
            immunities=["fire", "poison"],
            natural_abilities=["fire_form"],
            challenge_rating=2,
            experience_reward=450,
            loot_table=[],
        ),
        # CR 2-3: Tougher enemies
        "demon_lesser": Monster(
            id="demon_lesser",
            name="Lesser Demon",
            description="A minor fiend from the lower planes",
            monster_type=MonsterType.FIEND,
            size=MonsterSize.MEDIUM,
            armor_class=14,
            health=27,
            strength=14,
            dexterity=14,
            constitution=15,
            intelligence=12,
            wisdom=10,
            charisma=11,
            attack_bonus=4,
            damage_dice="1d8+3",
            damage_type="slashing",
            special_attacks=["hellfire", "dark_magic"],
            resistances=["fire", "poison", "cold"],
            immunities=["fire"],
            challenge_rating=2,
            experience_reward=450,
            loot_table=["sulfur", "gem"],
        ),
        "troll": Monster(
            id="troll",
            name="Troll",
            description="A massive regenerating brute from deep forests",
            monster_type=MonsterType.MONSTROSITY,
            size=MonsterSize.LARGE,
            armor_class=15,
            health=84,
            strength=18,
            dexterity=13,
            constitution=20,
            intelligence=3,
            wisdom=8,
            charisma=7,
            attack_bonus=5,
            damage_dice="2d8+4",
            damage_type="slashing",
            natural_abilities=["regeneration"],
            challenge_rating=5,
            experience_reward=1800,
            loot_table=["troll_hide"],
        ),
        "vampire": Monster(
            id="vampire",
            name="Vampire",
            description="An ancient undead creature of terrible power",
            monster_type=MonsterType.UNDEAD,
            size=MonsterSize.MEDIUM,
            armor_class=16,
            health=144,
            strength=18,
            dexterity=18,
            constitution=18,
            intelligence=17,
            wisdom=15,
            charisma=18,
            attack_bonus=7,
            damage_dice="2d6+4",
            damage_type="piercing",
            special_attacks=["charm", "blood_drain"],
            resistances=["necrotic"],
            immunities=["poison"],
            natural_abilities=["shapeshift", "regeneration", "undead_fortitude"],
            challenge_rating=13,
            experience_reward=10000,
            loot_table=["treasure"],
        ),
        # CR 3+: Dragons and powerful creatures
        "dragon_wyrmling": Monster(
            id="dragon_wyrmling",
            name="Red Dragon Wyrmling",
            description="A young red dragon, barely larger than a person",
            monster_type=MonsterType.DRAGON,
            size=MonsterSize.LARGE,
            armor_class=17,
            health=33,
            strength=15,
            dexterity=10,
            constitution=13,
            intelligence=12,
            wisdom=11,
            charisma=10,
            attack_bonus=4,
            damage_dice="1d10+2",
            damage_type="piercing",
            special_attacks=["fire_breath"],
            resistances=["fire"],
            natural_abilities=["flight", "fire_immunity"],
            challenge_rating=3,
            experience_reward=700,
            loot_table=["gold_coins", "ruby", "spell_scroll"],
        ),
        "dragon_young": Monster(
            id="dragon_young",
            name="Young Red Dragon",
            description="A dragon reaching its prime",
            monster_type=MonsterType.DRAGON,
            size=MonsterSize.HUGE,
            armor_class=18,
            health=110,
            strength=19,
            dexterity=10,
            constitution=17,
            intelligence=14,
            wisdom=13,
            charisma=15,
            attack_bonus=7,
            damage_dice="2d10+4",
            damage_type="piercing",
            special_attacks=["fire_breath", "tail_attack"],
            resistances=["fire"],
            natural_abilities=["flight", "legendary_actions"],
            challenge_rating=10,
            experience_reward=5900,
            loot_table=["dragon_treasure"],
        ),
        # More humanoids
        "cultist": Monster(
            id="cultist",
            name="Cultist",
            description="A fanatical follower of forbidden gods",
            monster_type=MonsterType.HUMANOID,
            size=MonsterSize.MEDIUM,
            armor_class=12,
            health=16,
            strength=11,
            dexterity=12,
            constitution=10,
            intelligence=13,
            wisdom=11,
            charisma=10,
            attack_bonus=2,
            damage_dice="1d6",
            damage_type="slashing",
            special_attacks=["dark_ritual"],
            challenge_rating=0.5,
            experience_reward=100,
            loot_table=["spell_scroll", "silver_coins"],
        ),
        "assassin": Monster(
            id="assassin",
            name="Assassin",
            description="A skilled killer trained in the art of murder",
            monster_type=MonsterType.HUMANOID,
            size=MonsterSize.MEDIUM,
            armor_class=16,
            health=78,
            strength=13,
            dexterity=16,
            constitution=13,
            intelligence=11,
            wisdom=11,
            charisma=10,
            attack_bonus=6,
            damage_dice="1d6+3",
            damage_type="piercing",
            special_attacks=["assassinate", "evasion"],
            challenge_rating=8,
            experience_reward=3900,
            loot_table=["gold_coins", "poison"],
        ),
        # Beasts
        "bear": Monster(
            id="bear",
            name="Bear",
            description="A large predatory mammal",
            monster_type=MonsterType.BEAST,
            size=MonsterSize.LARGE,
            armor_class=12,
            health=34,
            strength=15,
            dexterity=10,
            constitution=13,
            intelligence=2,
            wisdom=12,
            charisma=7,
            attack_bonus=4,
            damage_dice="1d8+2",
            damage_type="slashing",
            special_attacks=["multiattack"],
            challenge_rating=1,
            experience_reward=200,
            loot_table=["bear_hide"],
        ),
        "owlbear": Monster(
            id="owlbear",
            name="Owlbear",
            description="A monstrous fusion of owl and bear",
            monster_type=MonsterType.MONSTROSITY,
            size=MonsterSize.LARGE,
            armor_class=13,
            health=59,
            strength=20,
            dexterity=12,
            constitution=17,
            intelligence=3,
            wisdom=12,
            charisma=7,
            attack_bonus=7,
            damage_dice="2d8+5",
            damage_type="slashing",
            challenge_rating=3,
            experience_reward=700,
            loot_table=[],
        ),
        # Elementals
        "water_elemental": Monster(
            id="water_elemental",
            name="Water Elemental",
            description="A creature of pure elemental water",
            monster_type=MonsterType.ELEMENTAL,
            size=MonsterSize.LARGE,
            armor_class=14,
            health=52,
            strength=13,
            dexterity=14,
            constitution=16,
            intelligence=5,
            wisdom=10,
            charisma=8,
            attack_bonus=3,
            damage_dice="2d6+3",
            damage_type="bludgeoning",
            immunities=["poison"],
            challenge_rating=2,
            experience_reward=450,
            loot_table=[],
        ),
        "earth_elemental": Monster(
            id="earth_elemental",
            name="Earth Elemental",
            description="A humanoid of stone and earth",
            monster_type=MonsterType.ELEMENTAL,
            size=MonsterSize.LARGE,
            armor_class=15,
            health=104,
            strength=20,
            dexterity=8,
            constitution=20,
            intelligence=5,
            wisdom=10,
            charisma=5,
            attack_bonus=8,
            damage_dice="2d8+5",
            damage_type="bludgeoning",
            immunities=["poison"],
            challenge_rating=5,
            experience_reward=1800,
            loot_table=[],
        ),
        # Undead
        "skeleton": Monster(
            id="skeleton",
            name="Skeleton",
            description="Bones held together by dark magic",
            monster_type=MonsterType.UNDEAD,
            size=MonsterSize.MEDIUM,
            armor_class=15,
            health=13,
            strength=10,
            dexterity=14,
            constitution=15,
            intelligence=6,
            wisdom=8,
            charisma=5,
            attack_bonus=2,
            damage_dice="1d6+2",
            damage_type="piercing",
            immunities=["poison"],
            challenge_rating=0.125,
            experience_reward=25,
            loot_table=[],
        ),
        "lich": Monster(
            id="lich",
            name="Lich",
            description="An ancient wizard who achieved immortality through dark magic",
            monster_type=MonsterType.UNDEAD,
            size=MonsterSize.MEDIUM,
            armor_class=17,
            health=135,
            strength=8,
            dexterity=16,
            constitution=16,
            intelligence=18,
            wisdom=15,
            charisma=16,
            attack_bonus=6,
            damage_dice="1d6+3",
            damage_type="cold",
            special_attacks=["spellcasting", "paralysis"],
            immunities=["cold", "lightning", "poison"],
            natural_abilities=["legendary_actions", "phylactery"],
            challenge_rating=21,
            experience_reward=33000,
            loot_table=["legendary_treasure"],
        ),
    }
    
    def __init__(self, custom_monsters: Optional[Dict[str, Monster]] = None):
        self.monsters = dict(self.DEFAULT_MONSTERS)
        if custom_monsters:
            self.monsters.update(custom_monsters)
    
    def get_monster(self, monster_id: str) -> Optional[Monster]:
        """Get monster by ID"""
        return self.monsters.get(monster_id)
    
    def add_monster(self, monster: Monster) -> None:
        """Add custom monster"""
        self.monsters[monster.id] = monster
    
    def list_monsters(self) -> List[str]:
        """List all available monsters"""
        return list(self.monsters.keys())
    
    def get_monsters_by_type(self, monster_type: MonsterType) -> List[Monster]:
        """Get all monsters of a type"""
        return [m for m in self.monsters.values() if m.monster_type == monster_type]
    
    def get_monsters_by_cr(self, min_cr: float, max_cr: float) -> List[Monster]:
        """Get monsters by challenge rating range"""
        return [m for m in self.monsters.values() if min_cr <= m.challenge_rating <= max_cr]
    
    def spawn_random_monster(self, challenge_rating: float) -> Optional[Monster]:
        """Spawn random monster of given CR"""
        suitable = self.get_monsters_by_cr(challenge_rating * 0.5, challenge_rating * 1.5)
        if not suitable:
            return None
        return random.choice(suitable)
    
    def get_monster_count(self) -> int:
        """Get total number of monsters"""
        return len(self.monsters)

"""Base AI system interface"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from datetime import datetime


class AISystem(ABC):
    """Base class for all AI systems"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize AI system
        
        Args:
            config: Configuration dictionary
        """
        self.config = config or {}
        self.is_enabled = self.config.get("enabled", True)
        self.created_at = datetime.now()
    
    @abstractmethod
    async def initialize(self) -> None:
        """Initialize the AI system"""
        pass
    
    @abstractmethod
    async def update(self, delta_time: float) -> None:
        """Update AI system"""
        pass
    
    @abstractmethod
    async def shutdown(self) -> None:
        """Shutdown the AI system"""
        pass
    
    def is_online(self) -> bool:
        """Check if system should use online AI"""
        return self.config.get("online_mode", False)
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize AI system state"""
        return {
            "enabled": self.is_enabled,
            "config": self.config,
            "created_at": self.created_at.isoformat(),
        }

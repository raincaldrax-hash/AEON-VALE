"""Game save and load system"""

import json
import os
from typing import Dict, Any, Optional
from datetime import datetime
from pathlib import Path


class SaveManager:
    """Manages game save/load operations"""
    
    def __init__(self, save_dir: str = "saves"):
        """
        Initialize save manager
        
        Args:
            save_dir: Directory to store saves
        """
        self.save_dir = Path(save_dir)
        self.save_dir.mkdir(exist_ok=True)
    
    def save_game(self, game_state: Dict[str, Any], filename: str) -> bool:
        """Save game state to file"""
        try:
            save_path = self.save_dir / f"{filename}.json"
            
            # Add metadata
            save_data = {
                "metadata": {
                    "saved_at": datetime.now().isoformat(),
                    "version": "0.1.0",
                },
                "state": game_state,
            }
            
            with open(save_path, "w") as f:
                json.dump(save_data, f, indent=2)
            
            return True
        except Exception as e:
            print(f"Error saving game: {e}")
            return False
    
    def load_game(self, filename: str) -> Optional[Dict[str, Any]]:
        """Load game state from file"""
        try:
            save_path = self.save_dir / f"{filename}.json"
            
            if not save_path.exists():
                print(f"Save file not found: {save_path}")
                return None
            
            with open(save_path, "r") as f:
                save_data = json.load(f)
            
            return save_data.get("state")
        except Exception as e:
            print(f"Error loading game: {e}")
            return None
    
    def list_saves(self) -> list:
        """List all available saves"""
        saves = []
        for save_file in self.save_dir.glob("*.json"):
            saves.append(save_file.stem)
        return sorted(saves)
    
    def delete_save(self, filename: str) -> bool:
        """Delete a save file"""
        try:
            save_path = self.save_dir / f"{filename}.json"
            if save_path.exists():
                save_path.unlink()
                return True
            return False
        except Exception as e:
            print(f"Error deleting save: {e}")
            return False

"""Aria RPG Engine - AI-first game engine framework"""

__version__ = "0.1.0"
__author__ = "Devon"
__license__ = "MIT"

from src.aria.core.world import World
from src.aria.core.entity import Entity
from src.aria.game.character import Character
from src.aria.game.quest import Quest

__all__ = [
    "World",
    "Entity",
    "Character",
    "Quest",
]

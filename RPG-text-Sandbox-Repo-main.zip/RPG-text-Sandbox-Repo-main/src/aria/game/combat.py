"""Combat system"""

from typing import Tuple, Dict, Any
import random
from src.aria.game.character import Character


class CombatSystem:
    """Manages combat between characters"""
    
    @staticmethod
    def calculate_hit_chance(attacker: Character, defender: Character) -> float:
        """Calculate hit chance based on attributes"""
        attacker_accuracy = attacker.dexterity + attacker.skills.get("combat", 0) * 5
        defender_evasion = defender.dexterity + defender.defense
        
        base_chance = 0.6  # 60% base hit chance
        accuracy_diff = (attacker_accuracy - defender_evasion) / 100
        hit_chance = max(0.1, min(0.95, base_chance + accuracy_diff))
        
        return hit_chance
    
    @staticmethod
    def calculate_damage(attacker: Character, defender: Character) -> Tuple[int, bool]:
        """Calculate damage from attack. Returns (damage, is_critical)"""
        base_damage = attacker.attack_power + attacker.strength // 2
        
        # Check for critical
        is_critical = random.random() < attacker.critical_chance
        if is_critical:
            base_damage = int(base_damage * 1.5)
        
        # Add randomness
        variance = random.randint(-5, 5)
        total_damage = max(1, base_damage + variance - defender.defense // 2)
        
        return total_damage, is_critical
    
    @staticmethod
    def attack(attacker: Character, defender: Character) -> Dict[str, Any]:
        """Perform attack action"""
        result = {
            "attacker": attacker.name,
            "defender": defender.name,
            "hit": False,
            "critical": False,
            "damage": 0,
            "message": "",
        }
        
        # Check if hit
        hit_chance = CombatSystem.calculate_hit_chance(attacker, defender)
        if random.random() > hit_chance:
            result["message"] = f"{attacker.name} misses {defender.name}!"
            return result
        
        result["hit"] = True
        
        # Calculate damage
        damage, critical = CombatSystem.calculate_damage(attacker, defender)
        result["damage"] = damage
        result["critical"] = critical
        
        # Apply damage
        actual_damage = defender.take_damage(damage)
        
        if critical:
            result["message"] = f"{attacker.name} critically hits {defender.name} for {actual_damage} damage!"
        else:
            result["message"] = f"{attacker.name} hits {defender.name} for {actual_damage} damage!"
        
        return result

"""Quest system"""

from typing import Dict, Any, List
from dataclasses import dataclass


@dataclass
class Quest:
    """Quest definition"""
    id: str
    title: str
    description: str
    objectives: List[str]
    rewards: Dict[str, int]  # gold, exp, items, etc.
    difficulty: str  # easy, normal, hard, legendary
    status: str = "available"  # available, accepted, in_progress, completed, failed
    progress: int = 0  # 0-100
    
    def accept(self) -> None:
        """Accept quest"""
        self.status = "accepted"
    
    def complete(self) -> None:
        """Complete quest"""
        self.status = "completed"
        self.progress = 100
    
    def fail(self) -> None:
        """Fail quest"""
        self.status = "failed"
    
    def update_progress(self, amount: int) -> None:
        """Update quest progress"""
        self.progress = min(100, self.progress + amount)
        if self.progress == 100:
            self.status = "in_progress"

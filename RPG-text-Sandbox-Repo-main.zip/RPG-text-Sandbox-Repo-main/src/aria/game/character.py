"""Character/Player system"""

from typing import Dict, Any, Optional
from dataclasses import dataclass, field
from src.aria.core.entity import Entity


@dataclass
class Character(Entity):
    """Player/NPC character with stats and progression"""
    
    # Basic stats
    health: int = 100
    max_health: int = 100
    mana: int = 50
    max_mana: int = 50
    stamina: int = 100
    max_stamina: int = 100
    
    # Attributes
    strength: int = 10
    dexterity: int = 10
    constitution: int = 10
    intelligence: int = 10
    wisdom: int = 10
    charisma: int = 10
    
    # Progression
    level: int = 1
    experience: int = 0
    experience_to_level: int = 1000
    
    # Combat
    attack_power: int = 10
    defense: int = 5
    critical_chance: float = 0.1  # 10%
    
    # Inventory
    inventory: Dict[str, Any] = field(default_factory=dict)
    max_inventory_slots: int = 20
    
    # Skills and Magic
    skills: Dict[str, int] = field(default_factory=dict)  # skill_name -> level
    spells: Dict[str, int] = field(default_factory=dict)  # spell_name -> level
    
    def __post_init__(self):
        """Initialize character"""
        super().__post_init__()
        self.entity_type = "character"
    
    def take_damage(self, amount: int) -> int:
        """Take damage, return actual damage taken"""
        actual_damage = max(1, amount - self.defense // 2)
        self.health = max(0, self.health - actual_damage)
        return actual_damage
    
    def heal(self, amount: int) -> int:
        """Heal character"""
        healed = min(amount, self.max_health - self.health)
        self.health += healed
        return healed
    
    def restore_mana(self, amount: int) -> int:
        """Restore mana"""
        restored = min(amount, self.max_mana - self.mana)
        self.mana += restored
        return restored
    
    def restore_stamina(self, amount: int) -> int:
        """Restore stamina"""
        restored = min(amount, self.max_stamina - self.stamina)
        self.stamina += restored
        return restored
    
    def gain_experience(self, amount: int) -> bool:
        """Gain experience, returns True if level up"""
        self.experience += amount
        
        if self.experience >= self.experience_to_level:
            return self.level_up()
        return False
    
    def level_up(self) -> bool:
        """Level up character"""
        self.level += 1
        self.experience = 0
        self.experience_to_level = int(self.experience_to_level * 1.1)
        
        # Increase stats
        self.max_health += 10
        self.health = self.max_health
        self.max_mana += 5
        self.mana = self.max_mana
        self.max_stamina += 5
        self.stamina = self.max_stamina
        
        # Increase attributes slightly
        self.strength += 1
        self.intelligence += 1
        self.wisdom += 1
        
        return True
    
    def learn_skill(self, skill_name: str, level: int = 1) -> None:
        """Learn or upgrade a skill"""
        current_level = self.skills.get(skill_name, 0)
        self.skills[skill_name] = max(current_level, level)
    
    def learn_spell(self, spell_name: str, level: int = 1) -> None:
        """Learn or upgrade a spell"""
        current_level = self.spells.get(spell_name, 0)
        self.spells[spell_name] = max(current_level, level)
    
    def is_alive(self) -> bool:
        """Check if character is alive"""
        return self.health > 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        base_dict = super().to_dict()
        base_dict.update({
            "health": self.health,
            "max_health": self.max_health,
            "mana": self.mana,
            "max_mana": self.max_mana,
            "level": self.level,
            "experience": self.experience,
            "strength": self.strength,
            "dexterity": self.dexterity,
            "constitution": self.constitution,
            "intelligence": self.intelligence,
            "wisdom": self.wisdom,
            "charisma": self.charisma,
            "skills": self.skills,
            "spells": self.spells,
        })
        return base_dict

"""Main game loop and state manager"""

import asyncio
from typing import Optional, Callable, Any
from datetime import datetime
from src.aria.core.world import World


class GameLoop:
    """Main game loop managing tick rate and simulation"""
    
    def __init__(self, world: World, tick_rate: float = 60.0):
        """
        Initialize game loop
        
        Args:
            world: World instance
            tick_rate: Ticks per second (default 60 TPS)
        """
        self.world = world
        self.tick_rate = tick_rate
        self.tick_duration = 1.0 / tick_rate
        
        self.is_running = False
        self.current_tick = 0
        self.total_time = 0.0
        
        # Callbacks
        self.on_tick_callbacks = []
        self.on_update_callbacks = []
        self.last_tick_time = datetime.now()
    
    def register_tick_callback(self, callback: Callable[[int], Any]) -> None:
        """Register callback for each tick"""
        self.on_tick_callbacks.append(callback)
    
    def register_update_callback(self, callback: Callable[[float], Any]) -> None:
        """Register callback for each update"""
        self.on_update_callbacks.append(callback)
    
    async def tick(self) -> None:
        """Execute single game tick"""
        self.current_tick += 1
        self.total_time += self.tick_duration
        
        # Call tick callbacks
        for callback in self.on_tick_callbacks:
            if asyncio.iscoroutinefunction(callback):
                await callback(self.current_tick)
            else:
                callback(self.current_tick)
        
        # Update world
        self.world.simulate(self.tick_duration)
        
        # Call update callbacks
        for callback in self.on_update_callbacks:
            if asyncio.iscoroutinefunction(callback):
                await callback(self.tick_duration)
            else:
                callback(self.tick_duration)
    
    async def run(self, max_ticks: Optional[int] = None) -> None:
        """Run game loop"""
        self.is_running = True
        tick_count = 0
        
        try:
            while self.is_running:
                if max_ticks and tick_count >= max_ticks:
                    break
                
                await self.tick()
                tick_count += 1
                
                # Sleep to maintain tick rate
                await asyncio.sleep(self.tick_duration)
        finally:
            self.is_running = False
    
    def stop(self) -> None:
        """Stop the game loop"""
        self.is_running = False
    
    def get_fps(self) -> float:
        """Get current FPS (ticks per second)"""
        if self.total_time == 0:
            return 0
        return self.current_tick / self.total_time

"""World management system"""

from typing import Dict, List, Optional, Any
from datetime import datetime
from dataclasses import dataclass, field
from src.aria.core.entity import Entity


@dataclass
class World:
    """Main world container managing all entities and state"""
    
    id: str
    name: str
    description: str
    
    # Entity storage
    entities: Dict[str, Entity] = field(default_factory=dict)
    locations: Dict[str, Entity] = field(default_factory=dict)
    npcs: Dict[str, Entity] = field(default_factory=dict)
    items: Dict[str, Entity] = field(default_factory=dict)
    
    # World state
    time: float = 0.0  # Simulation time
    difficulty: str = "normal"
    seed: int = 0  # For procedural generation
    
    # Timestamps
    created_at: datetime = field(default_factory=datetime.now)
    last_simulated: datetime = field(default_factory=datetime.now)
    
    # Configuration
    config: Dict[str, Any] = field(default_factory=dict)
    
    def add_entity(self, entity: Entity) -> None:
        """Add entity to world"""
        self.entities[entity.id] = entity
        
        # Index by type
        if entity.entity_type == "location":
            self.locations[entity.id] = entity
        elif entity.entity_type == "npc":
            self.npcs[entity.id] = entity
        elif entity.entity_type == "item":
            self.items[entity.id] = entity
    
    def remove_entity(self, entity_id: str) -> bool:
        """Remove entity from world"""
        if entity_id not in self.entities:
            return False
        
        entity = self.entities[entity_id]
        del self.entities[entity_id]
        
        # Remove from type indices
        if entity.entity_type == "location":
            self.locations.pop(entity_id, None)
        elif entity.entity_type == "npc":
            self.npcs.pop(entity_id, None)
        elif entity.entity_type == "item":
            self.items.pop(entity_id, None)
        
        return True
    
    def get_entity(self, entity_id: str) -> Optional[Entity]:
        """Get entity by ID"""
        return self.entities.get(entity_id)
    
    def get_location(self, location_id: str) -> Optional[Entity]:
        """Get location by ID"""
        return self.locations.get(location_id)
    
    def get_npcs_at_location(self, location_id: str) -> List[Entity]:
        """Get all NPCs at a location"""
        return [npc for npc in self.npcs.values() if npc.location_id == location_id]
    
    def get_items_at_location(self, location_id: str) -> List[Entity]:
        """Get all items at a location"""
        return [item for item in self.items.values() if item.location_id == location_id]
    
    def simulate(self, delta_time: float) -> None:
        """Simulate world for delta_time seconds"""
        self.time += delta_time
        self.last_simulated = datetime.now()
        # Simulation logic will be added by AI systems
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert world to dictionary for serialization"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "time": self.time,
            "difficulty": self.difficulty,
            "seed": self.seed,
            "created_at": self.created_at.isoformat(),
            "last_simulated": self.last_simulated.isoformat(),
            "entities": {eid: e.to_dict() for eid, e in self.entities.items()},
            "config": self.config,
        }

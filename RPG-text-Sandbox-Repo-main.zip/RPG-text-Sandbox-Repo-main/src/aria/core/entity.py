"""Base entity system for all game objects"""

from typing import Dict, Any, Optional
from uuid import uuid4
from datetime import datetime
from dataclasses import dataclass, field


@dataclass
class Entity:
    """Base entity for all game objects (NPCs, items, locations, etc.)"""
    
    id: str = field(default_factory=lambda: str(uuid4()))
    name: str = ""
    description: str = ""
    entity_type: str = "generic"  # npc, item, location, etc.
    
    # Position in world
    location_id: Optional[str] = None
    
    # State and properties
    properties: Dict[str, Any] = field(default_factory=dict)
    
    # Timestamps
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    
    # AI and behavior
    ai_enabled: bool = False
    ai_config: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """Initialize entity"""
        self.updated_at = datetime.now()
    
    def update_property(self, key: str, value: Any) -> None:
        """Update entity property"""
        self.properties[key] = value
        self.updated_at = datetime.now()
    
    def get_property(self, key: str, default: Any = None) -> Any:
        """Get entity property"""
        return self.properties.get(key, default)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert entity to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "entity_type": self.entity_type,
            "location_id": self.location_id,
            "properties": self.properties,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "ai_enabled": self.ai_enabled,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Entity":
        """Create entity from dictionary"""
        entity = cls(
            id=data.get("id", str(uuid4())),
            name=data.get("name", ""),
            description=data.get("description", ""),
            entity_type=data.get("entity_type", "generic"),
            location_id=data.get("location_id"),
            properties=data.get("properties", {}),
            ai_enabled=data.get("ai_enabled", False),
            ai_config=data.get("ai_config", {}),
        )
        return entity

# Contributing to Aria RPG Engine

We welcome contributions! Here's how you can help:

## Getting Started

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## Code Style

- Follow PEP 8
- Use type hints
- Write docstrings for all functions and classes
- Format with Black

## Testing

All code should include tests:

```bash
pytest tests/
```

## Reporting Issues

When reporting issues, please include:

- Python version
- Operating system
- Steps to reproduce
- Expected vs actual behavior

## License

All contributions are licensed under MIT.
